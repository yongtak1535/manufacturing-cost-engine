# Manufacturing Cost Engine

제조원가 데이터 검증 및 Audit Layer — Phase 1 MVP

## 현재 상태

**설계 단계. 애플리케이션 코드 없음.**

| 단계 | 상태 |
|---|---|
| 데이터 모델 설계 | 완료 (`docs/01_dataset_design.md`) |
| 샘플 데이터셋 제작 사양 | 완료 (`docs/02_dataset_build_spec.md`) |
| 샘플 Excel 생성 | 미착수 — J-1 5개 값 결정 대기 |
| 데이터셋 무결성 검증 | 미착수 |
| DB Model / Rule Engine | 미착수 |

## 문서

| 파일 | 내용 |
|---|---|
| `docs/01_dataset_design.md` | Entity 필수/선택 구분, FK 관계, 회계 위험 검토 13항목, 확정/미확정 Rule 분리 |
| `docs/02_dataset_build_spec.md` | 모델 수정사항 20건, 파일 22개 컬럼 사양, 정상 10 / 오류 32 시나리오, README 가정 18항목 |

## 착수 전 결정 필요 (docs/02 §J-1)

애플리케이션 코드 작성 전에 아래 5개가 결정되어야 합니다.
값이 없는 상태에서 구현하면 근거 없는 계산 규칙이 만들어집니다.

1. BOM / Labor / GL Recon **tolerance 수치**
2. Material Issue **unit_cost 산정방식** (표준단가 / 이동평균 / 실제원가)
3. **잔업할증** `actual_rate` 포함 여부
4. **OH 예정배부율** 수치
5. **GL Reconciliation 허용차이**

## 핵심 원칙

- 금액·수량·단가 계산은 `Decimal`. float 금지
- 모든 계산은 deterministic Rule Engine. LLM은 계산에 개입하지 않음
- Account Mapping은 명시적 Master로만. 계정명·적요 keyword matching 금지
- 데이터 오류를 임의 보정하지 않음
- 불확실하면 `REVIEW_REQUIRED` / `NOT_CALCULABLE`
- 모든 원천 데이터에 `source_file` + `source_sheet` + `source_row` 추적

## 범위 제외 (Phase 1)

방산원가 자동판정 · Mix/Yield/Scrap 고급 Variance · 복잡한 WIP 회계처리 · ABC · 인증/결제 시스템

## 라이선스

미정
